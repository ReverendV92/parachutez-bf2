AddCSLuaFile("client/parachute_client.lua")

-- NO DOWNLOAD FOR YOU!
