ENT.Type = "anim"
ENT.PrintName		= "BF2 Decorative parachute"
ENT.Author			= "Jesse V-92"
ENT.Contact			= "desertyetti@firestormstudios.us"
ENT.Purpose			= "Save You."
ENT.Instructions	= "Obvious."

/*---------------------------------------------------------
OnRemove
---------------------------------------------------------*/
function ENT:OnRemove()
end

/*---------------------------------------------------------
PhysicsUpdate
---------------------------------------------------------*/
function ENT:PhysicsUpdate()
end

/*---------------------------------------------------------
PhysicsCollide
---------------------------------------------------------*/
function ENT:PhysicsCollide(data,phys)
end
