function DoParachute(ply)
if ply:GetMoveType() == MOVETYPE_NOCLIP then return end
if ply:InVehicle() then return end
if ply:OnGround() then return end
if ply:GetNWBool("Parachute") then return end
if ply:GetVelocity():Length() < 750 then return end
ply:SetNWBool("Parachute",true)
ply:EmitSound("ambient/fire/mtov_flame2.wav",100,90)
local Para = ents.Create("parachute_decor")
Para:SetOwner(ply)
Para:SetPos(ply:GetPos() + ply:GetUp()*130)
Para:SetAngles(ply:GetAngles())
Para:SetParent(ply)
Para:Spawn()
end
concommand.Add("parachutedo",DoParachute)

function ParachuteKey()
for k,v in pairs (player.GetAll()) do
if v:GetNWBool("Parachute") then
if v:KeyDown(IN_FORWARD) then
v:SetLocalVelocity(v:GetForward()*150 - v:GetUp()*350)
elseif v:KeyDown(IN_MOVELEFT) then
v:SetLocalVelocity(v:GetRight()*-150 - v:GetUp()*350)
elseif v:KeyDown(IN_MOVERIGHT) then
v:SetLocalVelocity(v:GetRight()*150 - v:GetUp()*350)
elseif v:KeyDown(IN_BACK) then
v:SetLocalVelocity(v:GetForward()*-150 - v:GetUp()*350)
else
v:SetLocalVelocity(v:GetUp()*-350)
end
end
if v:OnGround() and v:GetNWBool("Parachute") then
v:SetNWBool("Parachute",false)
v:SetGravity(1)
end
if v:KeyReleased(IN_JUMP) then
v:ConCommand("parachutedo")
end
end
end
hook.Add("Think","ParachuteKey",ParachuteKey)